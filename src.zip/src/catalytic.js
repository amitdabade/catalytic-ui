// for material design button
var buttons = document.getElementsByClassName('mt-button');
Array.prototype.forEach.call(buttons, function (b) {
    b.addEventListener('click', createRipple);
});

var toggleButtons = document.getElementsByClassName('mt-toggle-button');
Array.prototype.forEach.call(toggleButtons, function (b) {
    b.addEventListener('click', createRipple);
});

function createRipple (e) {
    if(this.getElementsByClassName('rippleEffect').length > 1){
//        if(this.childNodes.length>1){
            this.removeChild(this.childNodes[2]);
//        }
    }
    
    var circle = document.createElement('span');
    this.appendChild(circle);

    var d = Math.max(this.offsetWidth, this.offsetHeight);

    circle.style.width = d + 'px';
    circle.style.height = d + 'px';

    var rect = this.getBoundingClientRect();
    
    circle.style.left = e.clientX - rect.left -d/2 + 'px';
    circle.style.top = e.clientY - rect.top - d/2 + 'px';

    circle.classList.add('rippleEffect');
}

//for material design radio button
var radioButtons = document.getElementsByClassName('mt-radio');

Array.prototype.forEach.call(radioButtons, function (b) {
    if(b.childNodes[1].childNodes[1].getAttribute("disabled")==null){
        b.childNodes[1].addEventListener('click', createRadioRipple);
    }
    // var customRadio = document.createElement("span");
    // customRadio.classList.add("mt-radio-button");
    // b.childNodes[1].appendChild(customRadio);
});

function createRadioRipple(e) {
   if(this.getElementsByClassName('radioRippleEffect').length > 0){
       this.removeChild(this.childNodes[2]);     
   }
    var bodyRect = this.getBoundingClientRect(),
    elemRect = this.childNodes[1].getBoundingClientRect(),
    offset   = elemRect.top - bodyRect.top;
    console.log(offset);
    console.log(elemRect.top);
    console.log(bodyRect.top);


    var ripple = document.createElement('span');
    ripple.classList.add('radioRippleEffect');
    this.insertBefore(ripple,this.childNodes[3]);
}


//for material design checkbox
// var buttons = document.getElementsByClassName('mt-checkbox');

// Array.prototype.forEach.call(buttons, function (b) {
//     b.addEventListener('click', createCheckboxRipple);
// });

// function createCheckboxRipple() {
//     if(this.nextElementSibling.getElementsByClassName('checkboxRippleEffect').length > 0){
//         this.nextElementSibling.removeChild(this.nextElementSibling.childNodes[1]);      
//     }
    
//     var circle = document.createElement('span');
//     this.nextElementSibling.appendChild(circle);
    
//     circle.classList.add('checkboxRippleEffect');
// }
var checkboxButtons = document.getElementsByClassName('mt-checkbox');

Array.prototype.forEach.call(checkboxButtons, function (b) {
    if(b.childNodes[1].childNodes[1].getAttribute("disabled")==null){
        b.childNodes[1].addEventListener('click', createCheckboxRipple);
    }
    var customCheckbox = document.createElement("span");
    customCheckbox.classList.add("mt-checkbox-button");
    b.childNodes[1].appendChild(customCheckbox);
});

function createCheckboxRipple(e) {
   if(this.getElementsByClassName('checkboxRippleEffect').length > 0){
       this.removeChild(this.childNodes[2]);     
   }
    
    var ripple = document.createElement('span');
    ripple.classList.add('checkboxRippleEffect');
    this.insertBefore(ripple,this.childNodes[2]);
}

//for material design switch
var buttons = document.getElementsByClassName('mt-switch');

Array.prototype.forEach.call(buttons, function (b) {
    b.addEventListener('click', createSwitchRipple);
});

function createSwitchRipple() {
    if(this.getElementsByClassName('switchRippleEffect').length > 1){
//        this.removeChild(this.childNodes[2]);      
    }
    
    var circle = document.createElement('span');
    this.childNodes[1].appendChild(circle);
    circle.classList.add('switchRippleEffect');
    // this.insertBefore(circle,this.childNodes[2]);
}

//for material design slider
var mtSliders = document.getElementsByClassName('mt-slider');

Array.prototype.forEach.call(mtSliders, function (b) {
    sliderTag = document.createElement('span');  
    sliderTag.classList.add('mt-slider-highlight');
    b.appendChild(sliderTag);
    setInitWidth(b);
    b.addEventListener('input', setWidth);
    b.addEventListener('click', createSliderRipple);
});
function setInitWidth(tag) {
    
    var inputTag= tag.getElementsByTagName('input')[0];
    
    var min = parseInt(inputTag.min);
    var max = parseInt(inputTag.max);
    
    var userValue= parseInt(tag.getElementsByTagName('input')[0].value);
    
    var hightLightWidth=(((userValue-min)*100)/(max-min));
    
    tag.getElementsByClassName('mt-slider-highlight')[0].style.width=hightLightWidth+'%';
}
function setWidth() {
    var inputTag= this.getElementsByTagName('input')[0];
    
    var min = parseInt(inputTag.min);
    var max = parseInt(inputTag.max);
    
    var userValue= parseInt(this.getElementsByTagName('input')[0].value);
    
    var hightLightWidth=(((userValue-min)*100)/(max-min));
    
    this.getElementsByClassName('mt-slider-highlight')[0].style.width=hightLightWidth+'%';
}
function createSliderRipple() {  
     if(this.getElementsByClassName('sliderRippleEffect').length > 0){
        this.removeChild(this.childNodes[4]);      
    }
    var circle = document.createElement('span');
    this.appendChild(circle);  
    circle.classList.add('sliderRippleEffect');
    var inputTag= this.getElementsByTagName('input')[0];
    
    var min = parseInt(inputTag.min);
    var max = parseInt(inputTag.max);
    var userValue= parseInt(this.getElementsByTagName('input')[0].value);
    
    var hightLightWidth=(((userValue-min)*100)/(max-min));
     
    this.getElementsByClassName('sliderRippleEffect')[0].style.left='calc('+hightLightWidth+'%)';
}

//for material design input
var input = document.getElementsByClassName('mt-input');
Array.prototype.forEach.call(input, function (b) {
    if(b.value.length==0){
        b.nextElementSibling.classList.remove("hasValue");
    }else{
        b.nextElementSibling.classList.add("hasValue");
    }
    b.addEventListener('blur', isInputEmpty);    
});

function isInputEmpty(){
    if(this.value.length==0){
        this.nextElementSibling.classList.remove("hasValue");
    }else{
        this.nextElementSibling.classList.add("hasValue");
    }
    
}
//for material design input
var loaders = document.getElementsByClassName('mt-loader');

Array.prototype.forEach.call(loaders, function (b) {
    b.innerHTML="<svg class='mt-circle-loader'><circle cx='20' cy='20' r='15'></svg>";
});

//for material card view
var mtCardProtoType = Object.create(HTMLElement.prototype);
var mtCard = document.registerElement('mt-card', {
    prototype: mtCardProtoType
});


//for material design side drawer menu
var mtDrawer = document.getElementsByClassName('mt-drawer');

Array.prototype.forEach.call(mtDrawer, function (b) {
   
    console.log(b.childNodes[1].childNodes[1].className);
    if(b.childNodes[1].childNodes[1].className=='mt-side-menu'){   
        b.childNodes[1].childNodes[1].childNodes[1].addEventListener('click', openDrawer);
        b.childNodes[1].childNodes[1].nextElementSibling.style.marginLeft='50px';        
    }
});
function openDrawer() {
    this.parentElement.parentElement.parentElement.style.overflow='hidden';
    this.nextElementSibling.classList.add("mt-side-menu-open");
    var backdrop = document.createElement("div");
    backdrop.classList.add("mt-side-menu-backdrop");
    this.parentElement.appendChild(backdrop);
    this.parentElement.lastElementChild.addEventListener('click',closeDrawer);
}
function closeDrawer(){
    this.style.display="none";
    this.parentElement.childNodes[3].classList.remove("mt-side-menu-open");  this.parentElement.parentElement.parentElement.style.overflow='scroll';
}

//for material design side menu
var mtDrawer = document.getElementsByClassName('mt-menu');

Array.prototype.forEach.call(mtDrawer, function (b) {
   
    console.log(b.childNodes[1]);  
    b.childNodes[1].addEventListener('click', openMenu);
 
});
function openMenu() {
    this.nextElementSibling.style.display='inline-block';
    this.parentElement.parentElement.parentElement.addEventListener('click',closeMenu);
}
function closeMenu(e){
    if(e.target.className!="mt-icon-menu"){
        console.log('close menu');
        document.getElementsByClassName('mt-menu-options')[0].style.display="none";
    }     
}

//for material design tabs
var mtTabs = document.getElementsByClassName('mt-tab');
Array.prototype.forEach.call(mtTabs, function (b) {
    b.childNodes[1].childNodes[1].addEventListener('click',showData);
    
    console.log(b.childNodes[1].childNodes[1].checked);
    if(b.childNodes[1].childNodes[1].checked){
        console.log(b.childNodes[1].childNodes[1].getAttribute("data-tab"));
        var i=document.getElementsByClassName("mt-tab-container").length;
        var j=b.childNodes[1].childNodes[1].getAttribute('data-tab');
        document.getElementsByClassName("mt-tab-container")[j-1].style.background="red";
    }
});
function showData(){
    console.log(this.parentElement.parentElement);
     if(this.parentElement.parentElement.childNodes[1].childNodes[1].checked){
        console.log(this.parentElement.parentElement.childNodes[1].childNodes[1].getAttribute("data-tab"));
        var i=document.getElementsByClassName("mt-tab-container").length;
        var j=this.parentElement.parentElement.childNodes[1].childNodes[1].getAttribute('data-tab');
        for(k=1;k<=i;k++){
            if(k==j){
                document.getElementsByClassName("mt-tab-container")[j-1].style.background="red";
            }
            else{
                document.getElementsByClassName("mt-tab-container")[k].style.background="pink";
            }
         }
     }
}